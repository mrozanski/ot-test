(function(exports)
	{
		otui.ready(function(){
			otui.Menus.modify("home", {
				'title':otui.tr('')
			});

			NewFolderView.folderTypesChanged = function(event)
			{
				var value = $("#newFolderTypes")[0].selectedOptions[0];
				var metadataModelId = value.getAttribute('data-metadataModelId');
				var folderTypeId = value.getAttribute('data-folderTypeId');
				var parentView =  otui.Views.containing(event.currentTarget);
				parentView.storedProperty(NewFolderConst.METADATA_MODEL_ID, metadataModelId);
				parentView.storedProperty(NewFolderConst.FOLDER_TYPE_ID, folderTypeId);
				NewFolderView.showFolderTypesInfo(value);
			};

			NewFolderView.showFolderTypesInfo = function(folderType, context)
			{
				var thumbnailId = folderType.getAttribute('data-thumbnail');
				var description = folderType.getAttribute('data-description');

				var thumbnail = thumbnailId ? (otui.service + "/renditions/" + thumbnailId) : "img/folder_thumbnail.png";
				if(context)
				{
					context.find(".ot-newfolder-preview-description").text(description || "");
					context.find(".ot-newfolder-preview-image").attr("src", thumbnail);
				}
				else
				{
					$(".ot-newfolder-preview-description").text(description || "");
					$(".ot-newfolder-preview-image").attr("src", thumbnail);
				}

			};

			otui.MetadataModelManager.addContentTypes([
				{
					'name' : 'BITMAP',
					'displayName' : otui.tr("Image"),
					'icon' : 'img/status_image_icon.png',
					'fallback' : 'img/image_thumbnail.png'
				},
				{
					'name' : 'VIDEO',
					'displayName' : otui.tr("Video"),
					'icon' : 'img/status_video_icon.png',
					'fallback' : 'img/video_thumbnail.png'
				},
				{
					'name' : 'ACROBAT',
					'displayName' : otui.tr("Acrobat"),
					'icon' : 'img/status_acrobat_icon.png',
					'fallback' : 'img/acrobat_thumbnail.png'
				},
				{
					'name' : 'TXT',
					'displayName' : otui.tr("Text"),
					'icon' : 'img/mime_document_paper16_nf.png',
					'fallback' : 'img/mime_document_paper96_nf.png'
				},
				{
					'name' : 'AUDIO',
					'displayName' : otui.tr("Audio"),
					'icon' : 'img/status_audio_icon.png',
					'fallback' : 'img/audio_thumbnail.png'
				},
				{
					'name' : 'MSOFFICE',
					'displayName' : otui.tr("Microsoft Office"),
					'icon' : 'img/status_msoffice_icon.png',
					'fallback' : 'img/msoffice_thumbnail.png'
				},
				{
					'name' : 'HTML',
					'displayName' : otui.tr("HTML"),
					'icon' : 'img/mime_html16.png',
					'fallback' : 'img/mime_html96.png'
				},
				{
					'name' : 'XML',
					'displayName' : otui.tr("XML"),
					'icon' : 'img/mime_xml16.png',
					'fallback' : 'img/mime_xml96.png'
				},
				{
					'name' : 'LAYOUT',
					'displayName' : otui.tr("Layout"),
					'icon' : 'img/status_layout_icon.png',
					'fallback' : 'img/layout_thumbnail.png'
				},
				{
					'name' : 'unknown',
					'displayName' : otui.tr("Unknown"),
					'icon' : 'img/mime_type_unknown16.png',
					'fallback' : 'img/mime_type_unknown96.png'
				},
				{
					'name' : 'user',
					'displayName' : otui.tr("User"),
					'icon' : 'img/mime_user16.png',
					'fallback' : 'img/mime_user96.png'
				},
				{
					'name' : 'none',
					'displayName' : otui.tr("No content"),
					'icon' : 'img/status_txt_icon.png',
					'fallback' : 'img/txt_thumbnail.png'
				}
			])

		});

	}
)(otui);