(function(otui)
	{
	otui.ready(function()
		{
		otui.Menus.modify("home", {'title' : otui.tr("Home") });
		});
	})(otui);